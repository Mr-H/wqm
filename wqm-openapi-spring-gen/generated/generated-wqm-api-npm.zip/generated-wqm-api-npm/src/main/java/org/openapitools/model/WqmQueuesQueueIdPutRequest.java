package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import javax.validation.Valid;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import javax.annotation.Generated;

/**
 * WqmQueuesQueueIdPutRequest
 */

@JsonTypeName("_wqm_queues__queue_id__put_request")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-10-23T10:19:34.656008-04:00[America/New_York]")
public class WqmQueuesQueueIdPutRequest {

  private String queueName;

  private String queueDesc;

  private String queueType;

  private String queueStatus;

  public WqmQueuesQueueIdPutRequest queueName(String queueName) {
    this.queueName = queueName;
    return this;
  }

  /**
   * The new name of the work queue
   * @return queueName
  */
  
  @Schema(name = "queue_name", example = "an-updated-queue", description = "The new name of the work queue", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queue_name")
  public String getQueueName() {
    return queueName;
  }

  public void setQueueName(String queueName) {
    this.queueName = queueName;
  }

  public WqmQueuesQueueIdPutRequest queueDesc(String queueDesc) {
    this.queueDesc = queueDesc;
    return this;
  }

  /**
   * The new description of the work queue
   * @return queueDesc
  */
  
  @Schema(name = "queue_desc", example = "This is an updated work queue", description = "The new description of the work queue", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queue_desc")
  public String getQueueDesc() {
    return queueDesc;
  }

  public void setQueueDesc(String queueDesc) {
    this.queueDesc = queueDesc;
  }

  public WqmQueuesQueueIdPutRequest queueType(String queueType) {
    this.queueType = queueType;
    return this;
  }

  /**
   * The type of the queue (LIFO, FIFO, NONE)
   * @return queueType
  */
  
  @Schema(name = "queue_type", example = "LIFO", description = "The type of the queue (LIFO, FIFO, NONE)", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queue_type")
  public String getQueueType() {
    return queueType;
  }

  public void setQueueType(String queueType) {
    this.queueType = queueType;
  }

  public WqmQueuesQueueIdPutRequest queueStatus(String queueStatus) {
    this.queueStatus = queueStatus;
    return this;
  }

  /**
   * The new status of the work queue
   * @return queueStatus
  */
  
  @Schema(name = "queue_status", example = "ACTIVE", description = "The new status of the work queue", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queue_status")
  public String getQueueStatus() {
    return queueStatus;
  }

  public void setQueueStatus(String queueStatus) {
    this.queueStatus = queueStatus;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    WqmQueuesQueueIdPutRequest wqmQueuesQueueIdPutRequest = (WqmQueuesQueueIdPutRequest) o;
    return Objects.equals(this.queueName, wqmQueuesQueueIdPutRequest.queueName) &&
        Objects.equals(this.queueDesc, wqmQueuesQueueIdPutRequest.queueDesc) &&
        Objects.equals(this.queueType, wqmQueuesQueueIdPutRequest.queueType) &&
        Objects.equals(this.queueStatus, wqmQueuesQueueIdPutRequest.queueStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(queueName, queueDesc, queueType, queueStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class WqmQueuesQueueIdPutRequest {\n");
    sb.append("    queueName: ").append(toIndentedString(queueName)).append("\n");
    sb.append("    queueDesc: ").append(toIndentedString(queueDesc)).append("\n");
    sb.append("    queueType: ").append(toIndentedString(queueType)).append("\n");
    sb.append("    queueStatus: ").append(toIndentedString(queueStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

