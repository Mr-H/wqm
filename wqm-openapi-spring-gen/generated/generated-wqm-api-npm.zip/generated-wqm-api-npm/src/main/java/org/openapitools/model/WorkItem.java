package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import javax.validation.Valid;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import javax.annotation.Generated;

/**
 * WorkItem
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-10-23T10:19:34.656008-04:00[America/New_York]")
public class WorkItem {

  private Integer itemId;

  private String itemName;

  private String itemDesc;

  private String itemStatus;

  private String itemLock;

  public WorkItem itemId(Integer itemId) {
    this.itemId = itemId;
    return this;
  }

  /**
   * The unique identifier for the work queue item
   * @return itemId
  */
  
  @Schema(name = "item_id", example = "1", description = "The unique identifier for the work queue item", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("item_id")
  public Integer getItemId() {
    return itemId;
  }

  public void setItemId(Integer itemId) {
    this.itemId = itemId;
  }

  public WorkItem itemName(String itemName) {
    this.itemName = itemName;
    return this;
  }

  /**
   * The name of the work item
   * @return itemName
  */
  
  @Schema(name = "item_name", example = "work-item", description = "The name of the work item", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("item_name")
  public String getItemName() {
    return itemName;
  }

  public void setItemName(String itemName) {
    this.itemName = itemName;
  }

  public WorkItem itemDesc(String itemDesc) {
    this.itemDesc = itemDesc;
    return this;
  }

  /**
   * A description of the work item
   * @return itemDesc
  */
  
  @Schema(name = "item_desc", example = "This is a work item", description = "A description of the work item", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("item_desc")
  public String getItemDesc() {
    return itemDesc;
  }

  public void setItemDesc(String itemDesc) {
    this.itemDesc = itemDesc;
  }

  public WorkItem itemStatus(String itemStatus) {
    this.itemStatus = itemStatus;
    return this;
  }

  /**
   * The status of the work item
   * @return itemStatus
  */
  
  @Schema(name = "item_status", example = "OPEN", description = "The status of the work item", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("item_status")
  public String getItemStatus() {
    return itemStatus;
  }

  public void setItemStatus(String itemStatus) {
    this.itemStatus = itemStatus;
  }

  public WorkItem itemLock(String itemLock) {
    this.itemLock = itemLock;
    return this;
  }

  /**
   * The work item lock
   * @return itemLock
  */
  
  @Schema(name = "item_lock", example = "UNLOCKED", description = "The work item lock", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("item_lock")
  public String getItemLock() {
    return itemLock;
  }

  public void setItemLock(String itemLock) {
    this.itemLock = itemLock;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    WorkItem workItem = (WorkItem) o;
    return Objects.equals(this.itemId, workItem.itemId) &&
        Objects.equals(this.itemName, workItem.itemName) &&
        Objects.equals(this.itemDesc, workItem.itemDesc) &&
        Objects.equals(this.itemStatus, workItem.itemStatus) &&
        Objects.equals(this.itemLock, workItem.itemLock);
  }

  @Override
  public int hashCode() {
    return Objects.hash(itemId, itemName, itemDesc, itemStatus, itemLock);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class WorkItem {\n");
    sb.append("    itemId: ").append(toIndentedString(itemId)).append("\n");
    sb.append("    itemName: ").append(toIndentedString(itemName)).append("\n");
    sb.append("    itemDesc: ").append(toIndentedString(itemDesc)).append("\n");
    sb.append("    itemStatus: ").append(toIndentedString(itemStatus)).append("\n");
    sb.append("    itemLock: ").append(toIndentedString(itemLock)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

