package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import javax.validation.Valid;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import javax.annotation.Generated;

/**
 * WqmQueuesPostRequest
 */

@JsonTypeName("_wqm_queues_post_request")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-10-23T10:19:34.656008-04:00[America/New_York]")
public class WqmQueuesPostRequest {

  private String queueName;

  private String queueDesc;

  private String queueType;

  private String queueStatue;

  public WqmQueuesPostRequest() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public WqmQueuesPostRequest(String queueName, String queueDesc, String queueType) {
    this.queueName = queueName;
    this.queueDesc = queueDesc;
    this.queueType = queueType;
  }

  public WqmQueuesPostRequest queueName(String queueName) {
    this.queueName = queueName;
    return this;
  }

  /**
   * The name of the new work queue
   * @return queueName
  */
  @NotNull 
  @Schema(name = "queue_name", example = "a-queue", description = "The name of the new work queue", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("queue_name")
  public String getQueueName() {
    return queueName;
  }

  public void setQueueName(String queueName) {
    this.queueName = queueName;
  }

  public WqmQueuesPostRequest queueDesc(String queueDesc) {
    this.queueDesc = queueDesc;
    return this;
  }

  /**
   * A description of the new work queue
   * @return queueDesc
  */
  @NotNull 
  @Schema(name = "queue_desc", example = "This is my new work queue", description = "A description of the new work queue", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("queue_desc")
  public String getQueueDesc() {
    return queueDesc;
  }

  public void setQueueDesc(String queueDesc) {
    this.queueDesc = queueDesc;
  }

  public WqmQueuesPostRequest queueType(String queueType) {
    this.queueType = queueType;
    return this;
  }

  /**
   * The type of the queue (LIFO, FIFO, NONE)
   * @return queueType
  */
  @NotNull 
  @Schema(name = "queue_type", example = "LIFO", description = "The type of the queue (LIFO, FIFO, NONE)", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("queue_type")
  public String getQueueType() {
    return queueType;
  }

  public void setQueueType(String queueType) {
    this.queueType = queueType;
  }

  public WqmQueuesPostRequest queueStatue(String queueStatue) {
    this.queueStatue = queueStatue;
    return this;
  }

  /**
   * The status of the new work queue
   * @return queueStatue
  */
  
  @Schema(name = "queue_statue", example = "ACTIVE", description = "The status of the new work queue", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queue_statue")
  public String getQueueStatue() {
    return queueStatue;
  }

  public void setQueueStatue(String queueStatue) {
    this.queueStatue = queueStatue;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    WqmQueuesPostRequest wqmQueuesPostRequest = (WqmQueuesPostRequest) o;
    return Objects.equals(this.queueName, wqmQueuesPostRequest.queueName) &&
        Objects.equals(this.queueDesc, wqmQueuesPostRequest.queueDesc) &&
        Objects.equals(this.queueType, wqmQueuesPostRequest.queueType) &&
        Objects.equals(this.queueStatue, wqmQueuesPostRequest.queueStatue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(queueName, queueDesc, queueType, queueStatue);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class WqmQueuesPostRequest {\n");
    sb.append("    queueName: ").append(toIndentedString(queueName)).append("\n");
    sb.append("    queueDesc: ").append(toIndentedString(queueDesc)).append("\n");
    sb.append("    queueType: ").append(toIndentedString(queueType)).append("\n");
    sb.append("    queueStatue: ").append(toIndentedString(queueStatue)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

