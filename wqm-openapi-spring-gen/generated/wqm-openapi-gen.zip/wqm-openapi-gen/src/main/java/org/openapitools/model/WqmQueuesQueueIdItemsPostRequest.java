package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import javax.validation.Valid;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import javax.annotation.Generated;

/**
 * WqmQueuesQueueIdItemsPostRequest
 */

@JsonTypeName("_wqm_queues__queue_id__items_post_request")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-10-23T09:37:47.808649-04:00[America/New_York]")
public class WqmQueuesQueueIdItemsPostRequest {

  private String itemName;

  private String itemDesc;

  private String itemStatus;

  public WqmQueuesQueueIdItemsPostRequest() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public WqmQueuesQueueIdItemsPostRequest(String itemName, String itemDesc, String itemStatus) {
    this.itemName = itemName;
    this.itemDesc = itemDesc;
    this.itemStatus = itemStatus;
  }

  public WqmQueuesQueueIdItemsPostRequest itemName(String itemName) {
    this.itemName = itemName;
    return this;
  }

  /**
   * The name of the new queue item
   * @return itemName
  */
  @NotNull 
  @Schema(name = "item_name", example = "a-new-queue-item", description = "The name of the new queue item", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("item_name")
  public String getItemName() {
    return itemName;
  }

  public void setItemName(String itemName) {
    this.itemName = itemName;
  }

  public WqmQueuesQueueIdItemsPostRequest itemDesc(String itemDesc) {
    this.itemDesc = itemDesc;
    return this;
  }

  /**
   * A description of the new queue item
   * @return itemDesc
  */
  @NotNull 
  @Schema(name = "item_desc", example = "This is a new work queue item", description = "A description of the new queue item", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("item_desc")
  public String getItemDesc() {
    return itemDesc;
  }

  public void setItemDesc(String itemDesc) {
    this.itemDesc = itemDesc;
  }

  public WqmQueuesQueueIdItemsPostRequest itemStatus(String itemStatus) {
    this.itemStatus = itemStatus;
    return this;
  }

  /**
   * Work item status (OPEN, LOCKED, PROCESSED, DELETED)
   * @return itemStatus
  */
  @NotNull 
  @Schema(name = "item_status", example = "OPEN", description = "Work item status (OPEN, LOCKED, PROCESSED, DELETED)", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("item_status")
  public String getItemStatus() {
    return itemStatus;
  }

  public void setItemStatus(String itemStatus) {
    this.itemStatus = itemStatus;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    WqmQueuesQueueIdItemsPostRequest wqmQueuesQueueIdItemsPostRequest = (WqmQueuesQueueIdItemsPostRequest) o;
    return Objects.equals(this.itemName, wqmQueuesQueueIdItemsPostRequest.itemName) &&
        Objects.equals(this.itemDesc, wqmQueuesQueueIdItemsPostRequest.itemDesc) &&
        Objects.equals(this.itemStatus, wqmQueuesQueueIdItemsPostRequest.itemStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(itemName, itemDesc, itemStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class WqmQueuesQueueIdItemsPostRequest {\n");
    sb.append("    itemName: ").append(toIndentedString(itemName)).append("\n");
    sb.append("    itemDesc: ").append(toIndentedString(itemDesc)).append("\n");
    sb.append("    itemStatus: ").append(toIndentedString(itemStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

