package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import javax.validation.Valid;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import javax.annotation.Generated;

/**
 * Queue
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-10-23T09:37:47.808649-04:00[America/New_York]")
public class Queue {

  private Integer queueId;

  private String queueName;

  private String queueDesc;

  private String queueType;

  private String queueStatus;

  public Queue queueId(Integer queueId) {
    this.queueId = queueId;
    return this;
  }

  /**
   * The unique identifier for the queue
   * @return queueId
  */
  
  @Schema(name = "queue_id", example = "1", description = "The unique identifier for the queue", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queue_id")
  public Integer getQueueId() {
    return queueId;
  }

  public void setQueueId(Integer queueId) {
    this.queueId = queueId;
  }

  public Queue queueName(String queueName) {
    this.queueName = queueName;
    return this;
  }

  /**
   * The name of the queue
   * @return queueName
  */
  
  @Schema(name = "queue_name", example = "a-queue", description = "The name of the queue", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queue_name")
  public String getQueueName() {
    return queueName;
  }

  public void setQueueName(String queueName) {
    this.queueName = queueName;
  }

  public Queue queueDesc(String queueDesc) {
    this.queueDesc = queueDesc;
    return this;
  }

  /**
   * A description of the queue
   * @return queueDesc
  */
  
  @Schema(name = "queue_desc", example = "This is a work queue", description = "A description of the queue", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queue_desc")
  public String getQueueDesc() {
    return queueDesc;
  }

  public void setQueueDesc(String queueDesc) {
    this.queueDesc = queueDesc;
  }

  public Queue queueType(String queueType) {
    this.queueType = queueType;
    return this;
  }

  /**
   * The queue read order LIFO or FIFO or NONE
   * @return queueType
  */
  
  @Schema(name = "queue_type", example = "FIFO", description = "The queue read order LIFO or FIFO or NONE", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queue_type")
  public String getQueueType() {
    return queueType;
  }

  public void setQueueType(String queueType) {
    this.queueType = queueType;
  }

  public Queue queueStatus(String queueStatus) {
    this.queueStatus = queueStatus;
    return this;
  }

  /**
   * The status of the work queue
   * @return queueStatus
  */
  
  @Schema(name = "queue_status", example = "ACTIVE", description = "The status of the work queue", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("queue_status")
  public String getQueueStatus() {
    return queueStatus;
  }

  public void setQueueStatus(String queueStatus) {
    this.queueStatus = queueStatus;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Queue queue = (Queue) o;
    return Objects.equals(this.queueId, queue.queueId) &&
        Objects.equals(this.queueName, queue.queueName) &&
        Objects.equals(this.queueDesc, queue.queueDesc) &&
        Objects.equals(this.queueType, queue.queueType) &&
        Objects.equals(this.queueStatus, queue.queueStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(queueId, queueName, queueDesc, queueType, queueStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Queue {\n");
    sb.append("    queueId: ").append(toIndentedString(queueId)).append("\n");
    sb.append("    queueName: ").append(toIndentedString(queueName)).append("\n");
    sb.append("    queueDesc: ").append(toIndentedString(queueDesc)).append("\n");
    sb.append("    queueType: ").append(toIndentedString(queueType)).append("\n");
    sb.append("    queueStatus: ").append(toIndentedString(queueStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

